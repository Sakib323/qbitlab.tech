<?php
/**
 * Require App
 */
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/admin/class-post-type.php';

/**
 * Require Classes
 */
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/classes/class-enqueue.php';
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/classes/class-helpers.php';
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/classes/class-shortcode.php';

/**
 * Require App
 */
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/app/db.php';
require UXPER_CRYPTO_PLUGIN_DIR . 'includes/app/init.php';
<div class="uxper-meta-box-wrap">
	<?php uxper_get_template('templates/meta-box-section', array('list_section' => $list_section)) ?>
	<div class="uxper-fields">
		<div class="uxper-fields-wrapper">

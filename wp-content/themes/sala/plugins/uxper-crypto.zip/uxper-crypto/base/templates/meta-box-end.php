		</div> <!-- end .uxper-fields-wrapper -->
	</div> <!-- end .uxper-fields -->
</div> <!-- end .uxper-meta-box-wrap -->
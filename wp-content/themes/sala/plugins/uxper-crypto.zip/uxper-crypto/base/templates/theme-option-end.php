					</div> <!-- /.uxper-fields-wrapper -->
				</div> <!-- /.uxper-fields -->
			</div> <!-- /.uxper-m -->
			<div class="uxper-theme-options-footer">
				<button class="button button-primary uxper-theme-options-save-options" type="submit" name="uxper_save_option"><?php esc_html_e('Save Options','uxper-crypto'); ?></button>
			</div><!-- /.uxper-theme-options-footer -->
		</form>
	</div><!-- /.area-theme-options -->
</div><!-- /.uxper-theme-options-wrapper -->